WHAT IS THIS?
=============
This is a gnome-shell extension to open desktop folder.

Install
=======
https://extensions.gnome.org/extension/1120/desktop-folder/