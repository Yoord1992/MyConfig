A minimalist Trash management extension for the Gnome Shell.

It allows you to empty and open the Trash folder. It hides completely when the
Trash is empty, and lists the files in the trash bin in the panel menu.

To install, extract the archive or copy the folder to
~/.local/share/gnome-shell/extensions/ and restart the shell.
