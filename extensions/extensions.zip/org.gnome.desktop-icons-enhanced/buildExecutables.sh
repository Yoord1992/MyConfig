#!/bin/bash

mkdir buildExec
cd ./buildExec
cmake ../clipboard
make
