## todolist-gnome-shell-extension

Simple todo list extension for gnome-shell

## Installation

Go to [GNOME Shell page](https://extensions.gnome.org/extension/162/todo-list/) then switch on the button.

## License

Licensed under the GNU General Public License. See `COPYING` for details.
