# Gnome-Shell extension - User Icon Displayed

Simply show the current user's profile picture at the bottom of the main panel menu.  

![screenshot](./screenshot.png)